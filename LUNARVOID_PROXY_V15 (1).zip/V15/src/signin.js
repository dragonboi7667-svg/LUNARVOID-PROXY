// ===== Microsoft sign-in: one "Link account" button, code pre-filled on Microsoft's own page =====
// ONE-TIME SETUP: paste your Application (client) ID from your free Entra app registration between the quotes.
// (Personal Microsoft accounts + "Allow public client flows" = Yes. No secret is ever used.)
const MS_CLIENT_ID='';
const MS_AUTHORITY='https://login.microsoftonline.com/consumers/oauth2/v2.0';
const MS_REMOTE='https://login.live.com/oauth20_remoteconnect.srf';
const MS_SCOPES='XboxLive.signin offline_access';
let linked=safeGet('lv-account-linked',false)===true,linking=false;
function applyLock(){
  ['general','performance'].forEach(id=>{const b=$(`[data-st="${id}"]`);if(b){b.disabled=!linked;b.title=linked?'':'Link an account first';b.classList.toggle('locked',!linked)}});
  if($('#accountName'))$('#accountName').textContent=linked?'Linked account':'Not linked';
  const ab=$('#accountButton');if(ab)ab.textContent=linked?'Linked ✓':'Link account';
}
$$('[data-st]').forEach(b=>b.addEventListener('click',()=>{
  if(!linked&&b.dataset.st!=='account'){toast('Link your Microsoft account first.');return}
  $$('[data-st]').forEach(x=>x.classList.toggle('active',x===b));
  $$('.st').forEach(x=>x.classList.toggle('active',x.id==='st-'+b.dataset.st));
}));
function codeModal(code,url,onCancel){
  const m=document.createElement('div');m.style.cssText='position:fixed;inset:0;z-index:9999;background:#000b;display:grid;place-items:center;padding:20px';
  const card=document.createElement('div');card.style.cssText='max-width:440px;width:100%;background:#061427;border:1px solid #0877ff;border-radius:16px;padding:22px;color:#e8f4ff;text-align:center';
  const h=document.createElement('h2');h.style.marginTop='0';h.textContent='Finish on Microsoft';
  const p=document.createElement('p');p.textContent='Microsoft opened with your code filled in. Just sign in and press Enter / Next.';
  const c=document.createElement('div');c.style.cssText='font-size:30px;letter-spacing:4px;font-weight:800;padding:14px;background:#020914;border-radius:10px;color:#59c7ff';c.textContent=code;
  const a=document.createElement('a');a.href=url;a.target='_blank';a.rel='noopener';a.textContent='Page didn’t open? Tap here';a.style.cssText='display:block;margin:14px 0;color:#59c7ff';
  const x=document.createElement('button');x.className='secondary';x.textContent='Cancel';x.addEventListener('click',onCancel);
  card.append(h,p,c,a,x);m.append(card);document.body.append(m);return m;
}
async function linkMicrosoftAccount(){
  if(linking||linked)return;
  // Open the tab right on the click: popup blockers (Quest/Android included) block window.open after an await.
  let w=null;try{w=window.open('about:blank','_blank')}catch{}
  if(!MS_CLIENT_ID){
    if(w)w.location.href=MS_REMOTE;
    toast('Opened Microsoft. Set MS_CLIENT_ID in the code once to get the code pre-filled.');return;
  }
  linking=true;let modal=null,cancelled=false;
  const fail=msg=>{try{if(w&&w.location.href==='about:blank')w.close()}catch{}toast(String(msg||'Microsoft sign-in failed.').slice(0,180))};
  try{
    toast('Getting your Microsoft code…');
    let d;
    try{
      const r=await fetch(MS_AUTHORITY+'/devicecode',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id:MS_CLIENT_ID,scope:MS_SCOPES})});
      d=await r.json();if(!r.ok)throw new Error(d.error_description||d.error||'Microsoft rejected the request.');
    }catch(e){if(e instanceof TypeError)throw new Error('This page can’t reach Microsoft (the browser blocked the request). Use the app build.');throw e}
    if(!d.user_code||!d.device_code)throw new Error('Microsoft did not return a code.');
    const url=MS_REMOTE+'?otc='+encodeURIComponent(d.user_code);
    if(w)w.location.href=url;
    modal=codeModal(d.user_code,url,()=>{cancelled=true});
    const deadline=Date.now()+(d.expires_in||900)*1000;let wait=Math.max(5,d.interval||5);
    while(!cancelled&&Date.now()<deadline){
      await new Promise(r=>setTimeout(r,wait*1000));if(cancelled)break;
      let t;try{
        const r=await fetch(MS_AUTHORITY+'/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:device_code',client_id:MS_CLIENT_ID,device_code:d.device_code})});
        t=await r.json();if(r.ok&&t.access_token){linked=true;try{localStorage.setItem('lv-account-linked','true')}catch{}applyLock();toast('Microsoft account linked.');return}
      }catch{throw new Error('Lost connection to Microsoft. Try again.')}
      if(t.error==='authorization_pending')continue;
      if(t.error==='slow_down'){wait+=5;continue}
      if(t.error==='authorization_declined')throw new Error('Sign-in was declined.');
      if(t.error==='expired_token')break;
      throw new Error(t.error_description||t.error||'Microsoft sign-in failed.');
    }
    if(!cancelled)throw new Error('The code expired. Press Link account again.');
    toast('Sign-in cancelled.');
  }catch(err){fail(err.message)}
  finally{linking=false;modal?.remove()}
}
$('#accountButton')?.addEventListener('click',linkMicrosoftAccount);
applyLock();
