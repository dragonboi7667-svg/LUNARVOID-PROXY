// ===== 3D player preview: Three.js, standard Minecraft 64x64 skin UV layout =====
// Default skin = Steve (embedded). Uploaded skins: 64x64, 64x32 (legacy) or HD (128x128...), classic or slim arms.
const STEVE_B64='@@STEVE@@';
const canvas=$('#playerCanvas');
let GL=null,scene,cam,pivot,rig,baseMat,overMat,tex,limbs={},yaw=.6,pitch=.1,drag=null,raf=0,lastDrag=0,skinName='Steve',slim=false,useOverlay=false;
function boxGeo(w,h,d,u,v,g){
  const x=w/2+g,y=h/2+g,z=d/2+g,P=[],T=[],N=[],I=[];
  // [normal, TL, BL, BR, TR, texture region x,y,w,h]
  const F=[[[0,0,1],[-x,y,z],[-x,-y,z],[x,-y,z],[x,y,z],u+d,v+d,w,h],
   [[0,0,-1],[x,y,-z],[x,-y,-z],[-x,-y,-z],[-x,y,-z],u+2*d+w,v+d,w,h],
   [[-1,0,0],[-x,y,-z],[-x,-y,-z],[-x,-y,z],[-x,y,z],u,v+d,d,h],
   [[1,0,0],[x,y,z],[x,-y,z],[x,-y,-z],[x,y,-z],u+d+w,v+d,d,h],
   [[0,1,0],[-x,y,-z],[-x,y,z],[x,y,z],[x,y,-z],u+d,v,w,d],
   [[0,-1,0],[-x,-y,z],[-x,-y,-z],[x,-y,-z],[x,-y,z],u+d+w,v,w,d]];
  F.forEach((f,i)=>{const[rx,ry,rw,rh]=f.slice(5);
    const uv=[[rx,ry],[rx,ry+rh],[rx+rw,ry+rh],[rx+rw,ry]];
    for(let k=0;k<4;k++){P.push(...f[k+1]);N.push(...f[0]);T.push(uv[k][0]/64,1-uv[k][1]/64)}
    I.push(i*4,i*4+1,i*4+2,i*4,i*4+2,i*4+3)});
  const G=new THREE.BufferGeometry();
  G.setAttribute('position',new THREE.Float32BufferAttribute(P,3));
  G.setAttribute('normal',new THREE.Float32BufferAttribute(N,3));
  G.setAttribute('uv',new THREE.Float32BufferAttribute(T,2));G.setIndex(I);return G;
}
function mesh(w,h,d,u,v,g,mat,y){const m=new THREE.Mesh(boxGeo(w,h,d,u,v,g),mat);m.position.y=y;return m}
// A body part: base box + inflated overlay box, hung from a pivot so limbs can swing.
function part(name,w,h,d,u,v,ou,ov,px,py,pyMesh,og){
  const gr=new THREE.Group();gr.position.set(px,py,0);
  gr.add(mesh(w,h,d,u,v,0,baseMat,pyMesh));
  const o=mesh(w,h,d,ou,ov,og,overMat,pyMesh);o.userData.overlay=true;o.visible=useOverlay;gr.add(o);
  limbs[name]=gr;rig.add(gr);
}
function buildRig(){
  if(rig)pivot.remove(rig);
  rig=new THREE.Group();rig.position.y=-16;pivot.add(rig);limbs={};
  const aw=slim?3:4,ax=4+aw/2;
  part('head',8,8,8,0,0,32,0,0,24,4,.5);
  part('body',8,12,4,16,16,16,32,0,18,0,.25);
  part('armR',aw,12,4,40,16,40,32,-ax,24,-6,.25);
  part('armL',aw,12,4,32,48,48,48,ax,24,-6,.25);
  part('legR',4,12,4,0,16,0,32,-2,12,-6,.25);
  part('legL',4,12,4,16,48,0,48,2,12,-6,.25);
}
function initGL(){
  if(GL||!canvas)return !!GL;
  try{
    GL=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true});
    GL.setPixelRatio(Math.min(window.devicePixelRatio||1,2));GL.setSize(420,520,false);
    GL.outputEncoding=THREE.sRGBEncoding;
    scene=new THREE.Scene();cam=new THREE.PerspectiveCamera(26,420/520,1,400);cam.position.set(0,16,98);cam.lookAt(0,16,0);
    scene.add(new THREE.AmbientLight(0xffffff,.82));const dl=new THREE.DirectionalLight(0xffffff,.55);dl.position.set(20,40,60);scene.add(dl);
    pivot=new THREE.Group();pivot.position.y=16;scene.add(pivot);
    baseMat=new THREE.MeshLambertMaterial({alphaTest:.5});overMat=new THREE.MeshLambertMaterial({alphaTest:.5,transparent:true});
    canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();cancelAnimationFrame(raf);raf=0});
    canvas.addEventListener('webglcontextrestored',()=>{if(tex){tex.needsUpdate=true}drawPlayer()});
    setSkin(null);return true;
  }catch(err){GL=null;const hp=$('.viewer-help');if(hp)hp.textContent='3D preview needs WebGL, which this browser does not provide.';return false}
}
// Turn any skin image into a clean 64x64-layout canvas (handles legacy 64x32 + detects slim arms).
function prepSkin(img){
  const W=img.width,s=W/64,legacy=img.height*2===W,c=document.createElement('canvas');c.width=W;c.height=W;
  const x=c.getContext('2d');x.imageSmoothingEnabled=false;x.drawImage(img,0,0);
  if(legacy){
    const mir=(sx,sy,dx,dy,w,h,d)=>[[d,0,w,d,d,0],[d+w,0,w,d,d+w,0],[0,d,d,h,d+w,d],[d+w,d,d,h,0,d],[d,d,w,h,d,d],[2*d+w,d,w,h,2*d+w,d]].forEach(([ox,oy,fw,fh,tx,ty])=>{
      x.save();x.translate((dx+tx+fw)*s,(dy+ty)*s);x.scale(-1,1);x.drawImage(c,(sx+ox)*s,(sy+oy)*s,fw*s,fh*s,0,0,fw*s,fh*s);x.restore()});
    mir(40,16,32,48,4,12,4);mir(0,16,16,48,4,12,4);
  }
  const isSlim=!legacy&&x.getImageData(Math.floor(55*s),Math.floor(20*s),1,1).data[3]===0;
  return {c,isSlim};
}
function setSkin(img,opts={}){
  if(!GL&&!initGL())return;
  const src=img||STEVE_IMG;if(!src||!src.width)return;
  const r=prepSkin(src);slim=r.isSlim;useOverlay=!!img; // Steve's file has opaque filler outside the base layer, so overlays are skin-upload only
  if(tex)tex.dispose();
  tex=new THREE.CanvasTexture(r.c);tex.magFilter=THREE.NearestFilter;tex.minFilter=THREE.NearestFilter;tex.generateMipmaps=false;tex.encoding=THREE.sRGBEncoding;
  baseMat.map=tex;overMat.map=tex;baseMat.needsUpdate=true;overMat.needsUpdate=true;
  buildRig();drawPlayer();
  const sub=$('#skinSub');if(sub)sub.textContent=img?('Custom skin · '+(slim?'slim':'classic')+' arms'):'Default placeholder skin';
}
function frame(t){
  raf=0;
  if(!GL||document.hidden||!$('#page-player')?.classList.contains('active')||!$('#pt-skins')?.classList.contains('active'))return;
  const calm=document.body.classList.contains('reduced');
  if(!drag&&!calm&&t-lastDrag>2500)yaw+=.008;
  pivot.rotation.y=yaw;pivot.rotation.x=pitch;
  GL.render(scene,cam);raf=requestAnimationFrame(frame);
}
function drawPlayer(){if(!GL&&!initGL())return;if(!raf)raf=requestAnimationFrame(frame)}
const clampP=v=>Math.max(-.65,Math.min(.65,v));
$('#turnLeft')?.addEventListener('click',()=>{yaw-=.3;lastDrag=performance.now();drawPlayer()});$('#turnRight')?.addEventListener('click',()=>{yaw+=.3;lastDrag=performance.now();drawPlayer()});
$('#turnUp')?.addEventListener('click',()=>{pitch=clampP(pitch-.12);drawPlayer()});$('#turnDown')?.addEventListener('click',()=>{pitch=clampP(pitch+.12);drawPlayer()});
canvas?.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY};canvas.setPointerCapture?.(e.pointerId)});
canvas?.addEventListener('pointermove',e=>{if(!drag)return;yaw+=(e.clientX-drag.x)*.012;pitch=clampP(pitch+(e.clientY-drag.y)*.008);drag={x:e.clientX,y:e.clientY};lastDrag=performance.now();drawPlayer()});
['pointerup','pointercancel','lostpointercapture'].forEach(ev=>canvas?.addEventListener(ev,()=>{drag=null;lastDrag=performance.now()}));
document.addEventListener('visibilitychange',drawPlayer);
$$('[data-pt]').forEach(b=>b.addEventListener('click',()=>setTimeout(drawPlayer,0)));
// Steve default (embedded PNG) + saved skin restore
const STEVE_IMG=new Image();
function showSkinLabels(name){skinName=name;const nm=$('#skinName'),fn=$('#skinFileName');if(nm)nm.textContent=name;if(fn)fn.textContent=name==='Steve'?'No file selected':name}
function loadSkinData(data,name,quiet){
  const im=new Image();
  im.onload=()=>{const W=im.width,H=im.height;
    if(!(W>=64&&W%64===0&&(H===W||H*2===W))){toast('Skin must be a 64×64, 64×32 or HD (128×128) PNG.');return}
    setSkin(im);showSkinLabels(name);if(!quiet)toast('Skin applied to the 3D preview.');
    if(data.length<600000)safeSet('lv-skin',{name,data});};
  im.onerror=()=>toast('Could not read that image. Use a standard Minecraft skin PNG.');
  im.src=data;
}
STEVE_IMG.onload=()=>{const saved=safeGet('lv-skin',null);if(saved&&typeof saved.data==='string'&&saved.data.startsWith('data:image/png'))loadSkinData(saved.data,String(saved.name||'Saved skin'),true);else setSkin(null)};
STEVE_IMG.src='data:image/png;base64,'+STEVE_B64;
$('#skinUpload')?.addEventListener('change',e=>{const f=e.target.files?.[0];if(!f)return;
  if(f.type!=='image/png'&&!f.name.toLowerCase().endsWith('.png')){toast('Choose a Minecraft skin PNG file.');e.target.value='';return}
  if(f.size>1048576){toast('That file is too large for a skin.');e.target.value='';return}
  const fr=new FileReader();fr.onload=()=>loadSkinData(String(fr.result),f.name);fr.onerror=()=>toast('Could not read that file.');fr.readAsDataURL(f);e.target.value=''});
$('#clearSkin')?.addEventListener('click',()=>{try{localStorage.removeItem('lv-skin')}catch{}if($('#skinUpload'))$('#skinUpload').value='';setSkin(null);showSkinLabels('Steve');toast('Steve placeholder restored.')});
