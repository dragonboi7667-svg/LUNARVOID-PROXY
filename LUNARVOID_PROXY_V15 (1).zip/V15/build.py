#!/usr/bin/env python3
"""Builds dist/index.html: ONE self-contained file (needed because Quest/Android content:// URLs can't load sibling files)."""
import base64, pathlib
r = pathlib.Path(__file__).parent; s = r/'src'
rd = lambda p: (s/p).read_text(encoding='utf-8')
steve = base64.b64encode((s/'assets/steve.png').read_bytes()).decode()
js = rd('app.js').replace('/*@@SIGNIN@@*/', rd('signin.js')).replace('/*@@PLAYER3D@@*/', rd('player3d.js').replace('@@STEVE@@', steve))
svg = base64.b64encode((s/'assets/minecraft-landscape.svg').read_bytes()).decode()
html = rd('index.html').replace('@@CSS@@', rd('styles.css').replace("url('assets/minecraft-landscape.svg')", "url('data:image/svg+xml;base64,"+svg+"')")).replace('@@THREE@@', (s/'vendor/three.min.js').read_text(encoding='utf-8')).replace('@@JS@@', js)
(r/'dist').mkdir(exist_ok=True); (r/'dist/index.html').write_text(html, encoding='utf-8')
print('built dist/index.html', round(len(html)/1024), 'KB')
